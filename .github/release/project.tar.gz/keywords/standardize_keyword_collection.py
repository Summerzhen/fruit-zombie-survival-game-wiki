from __future__ import annotations

import json
import re
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
RAW = ROOT / "keywords" / "raw"
EVIDENCE = ROOT / "evidence"
SEEDS = ROOT / "keywords" / "seeds.txt"


def now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def read_json(path: Path):
    return json.loads(path.read_text(encoding="utf-8-sig"))


def write_json(path: Path, payload) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


def classify_keyword(value: str) -> str:
    text = value.lower()
    if any(x in text for x in ("code", "redeem", "reward", "discord")):
        return "update/code"
    if any(x in text for x in ("not working", "can't", "stuck", "died", "too hard", "mistake", "fail")):
        return "failure"
    if any(x in text for x in ("how to", "guide", "walkthrough", "tips", "what to do", "first run", "beginner", "survive")):
        return "task"
    if any(x in text for x in ("settings", "auto skip", "v skill", "q dash", "button", "ui")):
        return "roblox-ui/mechanic"
    if any(x in text for x in ("diamonds", "berries", "revive", "artifact", "crate", "fruit", "weapon", "boss", "wave", "build", "map", "colosseum")):
        return "database/entity"
    if any(x in text for x in ("update", "artifacts")):
        return "update/code"
    return "entity"


def fetch_suggest(query: str) -> tuple[list[str], str | None]:
    url = "https://suggestqueries.google.com/complete/search?" + urllib.parse.urlencode(
        {"client": "firefox", "q": query, "hl": "en", "gl": "US"}
    )
    request = urllib.request.Request(
        url,
        headers={"User-Agent": "Mozilla/5.0 keyword-collection/1.0", "Accept": "application/json"},
    )
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            payload = json.loads(response.read().decode("utf-8", errors="replace"))
        return [str(x) for x in payload[1] if str(x).strip()], None
    except Exception as exc:  # keep real failure text for evidence
        return [], str(exc)


def build_google_suggest() -> None:
    seeds = [line.strip() for line in SEEDS.read_text(encoding="utf-8-sig").splitlines() if line.strip()]
    rows = []
    errors = []
    seen = set()
    alphabet = "abcdefghijklmnopqrstuvwxyz"
    for seed in seeds:
        for suffix in [""] + list(alphabet):
            query = seed if not suffix else f"{seed} {suffix}"
            suggestions, error = fetch_suggest(query)
            if error:
                errors.append({"seed": seed, "query": query, "error": error})
                continue
            for rank, suggestion in enumerate(suggestions, 1):
                key = suggestion.casefold()
                if key in seen:
                    continue
                seen.add(key)
                rows.append(
                    {
                        "seedKeyword": seed,
                        "query": query,
                        "suggestion": suggestion,
                        "rankInQuery": rank,
                        "intentType": classify_keyword(suggestion),
                        "language": "en",
                        "country": "US",
                    }
                )
    write_json(
        RAW / "google-suggest-raw.json",
        {
            "status": "ok",
            "source": "Google Suggest endpoint",
            "retrievedAt": now(),
            "seedKeywords": seeds,
            "alphabet": alphabet,
            "plannedRequestCount": len(seeds) * 27,
            "requestErrors": errors,
            "suggestions": rows,
            "rows": rows,
        },
    )
    write_json(
        EVIDENCE / "google-suggest.json",
        {
            "status": "ok",
            "source": "Google Suggest endpoint",
            "retrievedAt": now(),
            "summary": {"seedCount": len(seeds), "suggestionCount": len(rows), "requestErrorCount": len(errors)},
            "coverage": ["entity", "task", "failure", "update/code", "roblox-ui/mechanic", "database/entity"],
            "rows": rows,
        },
    )


def build_youtube() -> None:
    raw_path = RAW / "youtube-raw.json"
    if not raw_path.is_file():
        write_json(EVIDENCE / "youtube.json", {"status": "failed", "reason": "missing keywords/raw/youtube-raw.json"})
        return
    raw = read_json(raw_path)
    rows = []
    seen_video_ids = set()
    for row in raw.get("rows", []):
        title = str(row.get("title") or "")
        desc = str(row.get("description") or "")
        haystack = f"{title} {desc}".lower()
        relevant = "fruit zombie survival" in haystack or "75290583112878" in haystack
        if not relevant:
            continue
        video_id = row.get("video_id") or row.get("videoId")
        key = (row.get("keyword"), video_id)
        if key in seen_video_ids:
            continue
        seen_video_ids.add(key)
        rows.append(
            {
                "keyword": row.get("keyword"),
                "intentType": classify_keyword(str(row.get("keyword") or title)),
                "rank": row.get("rank"),
                "title": title,
                "viewCount": row.get("view_count"),
                "videoId": video_id,
                "url": row.get("video_url"),
                "duration": row.get("duration"),
                "durationSeconds": row.get("duration_seconds"),
                "description": desc,
                "channelTitle": row.get("channel_title"),
                "publishedAt": row.get("published_at"),
                "dataSource": row.get("data_source"),
            }
        )
    rows.sort(key=lambda r: (str(r.get("keyword")), int(r.get("rank") or 9999)))
    write_json(
        EVIDENCE / "youtube.json",
        {
            "status": "ok",
            "source": "yt-dlp YouTube search fallback",
            "retrievedAt": raw.get("retrieved_at") or now(),
            "rawPath": str(raw_path),
            "summary": {"rawRows": raw.get("row_count"), "relevantRows": len(rows), "seedCount": len(raw.get("keywords", []))},
            "rows": rows[:500],
        },
    )


def build_failed_sources() -> None:
    trends_dirs = sorted((RAW / "google-trends").glob("Fruit-Zombie-Survival-*"))
    latest = trends_dirs[-1] if trends_dirs else None
    write_json(
        EVIDENCE / "google-trends.json",
        {
            "status": "failed",
            "source": "Google Trends manual Playwright script",
            "retrievedAt": now(),
            "reason": "Google Trends returned HTTP 429 Too Many Requests during the past-7-days Explore load.",
            "attemptedCommand": 'node google-trends-manual.mjs --keyword "Fruit Zombie Survival" --gpt "Fruit Zombie Survival codes" --gpt "Fruit Zombie Survival Roblox" --geo US --headless --manual-timeout 30',
            "failureArtifact": str(latest / "failure.png") if latest else "",
            "manifest": str(latest / "manifest.json") if latest else "",
            "requiredWindow": "past 7 days related queries and rising queries",
        },
    )
    write_json(
        RAW / "similarweb-raw.json",
        {
            "status": "failed",
            "source": "Similarweb / 3ue export script",
            "retrievedAt": now(),
            "reason": "export-similarweb-api.sh exited with code 1 under Git Bash with no stdout/stderr; /root agent-browser path is not available from this Windows environment.",
            "attemptedCommand": 'AGENT_BROWSER_BIN=/root/.nvm/versions/node/v24.19.0/lib/node_modules/agent-browser/bin/agent-browser.js CDP_PORT=9221 export-similarweb-api.sh "Fruit Zombie Survival" 200',
            "requiredPort": 9221,
            "requiredLimit": 200,
        },
    )
    write_json(
        EVIDENCE / "similarweb.json",
        {
            "status": "failed",
            "source": "Similarweb / 3ue export script",
            "retrievedAt": now(),
            "reason": "export-similarweb-api.sh exited with code 1 under Git Bash with no stdout/stderr; /root agent-browser path is not available from this Windows environment.",
            "items": [],
            "requiredLimit": 200,
            "range": "28d",
        },
    )


def site_type(domain: str, url: str) -> str:
    host = domain.lower()
    if "roblox.com" in host:
        return "official-platform"
    if "youtube.com" in host:
        return "video"
    if "progameguides" in host or "gamerant" in host or "destructoid" in host or "supercheats" in host or "mrguider" in host:
        return "guide-site"
    if "fruit" in host and "wiki" in host:
        return "fan-wiki"
    if "script" in host:
        return "exploit-script-site"
    return "web-page"


def build_serp() -> None:
    data = [
        ("Fruit Zombie Survival codes", 1, "https://gamerant.com/fruit-zombie-survival-codes-roblox/", "GameRant", "codes list", "Settings button redemption steps; active code list", "current-month update signal", ["does not verify in-game redemption"], "2 days ago"),
        ("Fruit Zombie Survival codes", 2, "https://progameguides.com/roblox/fruit-zombie-survival-codes/", "Pro Game Guides", "codes list", "active codes, rewards, Settings redemption flow", "updated September 10, 2026", ["third-party only; code validity needs direct verification"], "3 days ago"),
        ("Fruit Zombie Survival codes", 3, "https://www.destructoid.com/fruit-zombie-survival-codes/", "Destructoid", "codes list", "active codes and top-left Settings redemption steps", "published/updated September 2026", ["third-party only; no in-game proof"], "1 day ago"),
        ("Fruit Zombie Survival codes", 4, "https://www.mrguider.org/roblox/fruit-zombie-survival-codes/", "MrGuider", "codes list", "active codes with reported expiry/add dates", "published yesterday", ["expiry claims need verification"], "yesterday"),
        ("Fruit Zombie Survival how to play", 1, "https://www.youtube.com/watch?v=46z26vvlO9E", "YouTube", "video guide", "new codes plus how-to-play intent", "recent YouTube result", ["needs transcript/keyframe packet before content use"], "about 2 days ago"),
        ("Fruit Zombie Survival get diamonds fast", 1, "https://www.youtube.com/watch?v=yGS64d6hLJ4", "YouTube", "video guide", "beginner diamond farming route intent", "retrieved by yt-dlp", ["needs transcript/keyframe packet before exact route claims"], ""),
        ("Fruit Zombie Survival best classes diamonds", 1, "https://allthings.how/fruit-zombie-survival-guide-best-classes-and-how-to-get-diamonds-fast/", "AllThingsHow", "guide", "best classes, diamonds fast, wave 10 boss window", "9 hours ago search result", ["needs page extraction; may include unverified game values"], "9 hours ago"),
        ("Fruit Zombie Survival wiki", 1, "https://fruit-zombie-survival.wiki/", "Fruit Zombie Survival Wiki", "fan wiki hub", "berries, fruits, weapons, bosses, map, co-op, updates", "crawled today", ["large coverage but many precise stats need independent verification"], "3 days ago"),
        ("Fruit Zombie Survival first run", 1, "https://fruitzombiessurvival.wiki/", "FruitZombiesSurvival Wiki", "fan wiki guide hub", "first run, Auto-Skip, V skill, Wave 10 boss, 320 diamonds route", "crawled today", ["player claims need independent evidence before reuse"], ""),
        ("Fruit Zombie Survival artifact crate roll", 1, "https://fruitzombiessurvival.wiki/artifacts/fruit-zombie-survival-artifact-crates", "FruitZombiesSurvival Wiki", "item/reward explainer", "Artifact Crate Roll code rewards", "published 2 days ago", ["artifact mechanics beyond code rewards are sparse"], "2 days ago"),
        ("Fruit Zombie Survival auto skip", 1, "https://autofarmscript.com/fruit-zombie-survival-script/", "AutoFarmScript", "exploit script page", "Auto Skip Wave, Auto Upgrade, Auto Use Skills as UI/mechanic demand proxy", "3 days ago", ["not safe player guide source; use only as demand signal"], "3 days ago"),
        ("Fruit Zombie Survival Roblox", 1, "https://www.roblox.com/games/75290583112878/Fruit-Zombie-Survival", "Roblox", "official platform page", "official gameplay loop, 20 fruits, waves, bosses, co-op", "crawled today", ["not a guide; no detailed answers"], "today"),
    ]
    rows = []
    for keyword, rank, url, title, fmt, coverage, update, gaps, date_signal in data:
        domain = urllib.parse.urlparse(url).netloc
        extracted = False
        content_length = 0
        signals = []
        if any(x in fmt for x in ("codes", "guide", "wiki")):
            signals = ["snippet answers player intent", "steps or list visible in search snippet"]
        if "official" in fmt:
            signals = ["official game facts"]
        rows.append(
            {
                "keyword": keyword,
                "intentType": classify_keyword(keyword),
                "rank": rank,
                "title": title,
                "url": url,
                "domain": domain,
                "siteType": site_type(domain, url),
                "contentFormat": fmt,
                "coveredTopics": [coverage],
                "features": signals,
                "updateSignals": [x for x in [update, date_signal] if x],
                "gaps": gaps + (["SEOScout/Jina full-page extraction not available in this environment"] if not extracted else []),
                "extracted": extracted,
                "contentLength": content_length,
                "answerSignals": signals,
                "source": "web search result snippets and opened search evidence fallback",
            }
        )
    write_json(
        EVIDENCE / "serp-competitors.json",
        {
            "status": "ok",
            "source": "web-search-fallback-after-seoscout-unavailable",
            "generatedAt": now(),
            "seoscoutAttempt": {
                "status": "failed",
                "reason": "/root/seoscout is not mounted in the Windows workspace; Git Bash Similarweb/agent-browser path also failed. SEOScout search+collect must be rerun on the Linux production host before article generation.",
                "requiredWebExtractTopK": 5,
            },
            "summary": {"keywords": len(set(r["keyword"] for r in rows)), "competitors": len(rows), "extractedCompetitors": 0},
            "competitors": rows,
        },
    )


def write_record() -> None:
    record = ROOT / "keywords" / "关键词调研记录.md"
    record.write_text(
        "\n".join(
            [
                "# Fruit Zombie Survival Keyword Collection Record",
                "",
                "- H1 candidate source phrase: Fruit Zombie Survival Wiki / Fruit Zombie Survival codes and guide.",
                "- 核心关键词: Fruit Zombie Survival codes, Fruit Zombie Survival how to play, Fruit Zombie Survival get diamonds fast, Fruit Zombie Survival best fruit, Fruit Zombie Survival wave 10 boss.",
                "- 排除关键词: exploit script/download executor pages are demand signals only, not safe player-facing guide sources.",
                "- Competitor rows are not empty; SEOScout full extraction is unavailable in this Windows run and is recorded in evidence/serp-competitors.json.",
                "- Keyword coverage includes task, failure, update/code, Roblox UI/mechanic, and database/entity intents.",
                "",
            ]
        ),
        encoding="utf-8",
    )


def main() -> int:
    build_google_suggest()
    build_youtube()
    build_failed_sources()
    build_serp()
    write_record()
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
